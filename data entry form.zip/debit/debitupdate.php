

<?php
include ("debitdb.php");
$id  = $_GET['id'];

$query  = "SELECT * FROM debitdata WHERE id='$id'";
$data   = mysqli_query($conn,$query);
// $total  = mysqli_num_row($data);
$result = mysqli_fetch_assoc($data);
?>



<?php
if($_POST['update'])
{
    $name      = $_POST['name'];
    $address   = $_POST['address'];
    $amount    = $_POST['amount'];
    $date      = $_POST['date'];
    $type      = $_POST['type'];
    $remarks   = $_POST['remarks'];

    $query = "UPDATE debitdata SET name='$name', address='$address', amount='$amount', date='$date', type='$type', remarks='$remarks' WHERE id='$id'";
    $data  = mysqli_query($conn,$query);
    if($data){
        echo "<script> alert('Data has been update.')</script>";
        ?>

<meta http-equiv ="refresh" content="0; url = http://localhost/debit/debittable.php?id=1# "/>

        <?php

    }else{
        echo "Not Updated";
    }
}
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="debitform.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update data entry</title>
</head>
<body>

<div class="main">
  <h2>Update Debit Data Entry Form</h2>
  <p>Are you want update this data </p>
 <center>

 <a href="debittable.php"><button class="mytop">Data</button></a> 
 <a href=""><button class="logout">Logout</button></a> 
 
  <form class="form" method="post" autocomplete="off">
  <br>
    <input type="text" value="<?php echo $result['name'];?>" name="name" id="name" class="input" placeholder="Name" required>
    <br><br>
    <input type="text" value="<?php echo $result['address'];?>" name="address" id="address" class="input" placeholder="Address" required>
    <br><br>
    <input type="text" value="<?php echo $result['amount'];?>" name="amount" id="amount" class="input" placeholder="Amount" required>
    <br><br>
    <input type="text" value="<?php echo $result['date'];?>" name="date" id="date" class="input" placeholder="Date" required>
    <br><br>
    <input type="text" value="<?php echo $result['type'];?>" name="type" id="type" class="input" placeholder="Type" required>
    <br><br>
    <input type="text" value="<?php echo $result['remarks'];?>" name="remarks" id="remarks" class="input" placeholder="Remarks" required>
    <br><br>
    <input type="submit" name="update"  class="enter" value="Update">
    <br><br>
    <a href="http://localhost/debit/debittable.php"><input type="button" class="cencel" value="Cancel"></a>
    <br><br>
  </form>
</center>
  </div>













