<?php
session_start();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="debitlogin.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>debit-login</title>
</head>
<body>
    <center>
   <div class="login">
    <h2>My Debit</h2>
    <form  method="POST" autocomplete="off">
    <div class="input">
        <input type="text" name="user" class="ifield" value="@mydebit" required><br><br>
       
        <input type="password" name="password" id="icon" class="ifield" placeholder=" Password" required><br><br>

        <div class="cbx">
        <input type="checkbox" id="cbx" onclick="show()"> Show </input><br><br>
        </div>
    
        <input type="submit" name="enter" class="efield" value="Login">
    </div>
    </form>
   </div> 
</center>
</body>

<script>
    function show(){
        let ab = document.getElementById("icon");
        if(icon.type == 'password'){
            icon.type = 'text';
        }else{
            icon.type = 'password';
        }
    }
</script>


</html>



<?php
include ("debitLogindb.php");

if(isset($_POST['enter'])){
    $user  = $_POST['user'];
    $password  = $_POST['password'];

    $query = "SELECT * FROM debituser WHERE user = '$user' && password = '$password'";
    $data  = mysqli_query($conn,$query);
    $total = mysqli_num_rows($data);

    if($total == 1){
     
//this line below SESSION
       $user = $_SESSION['user'] = $user;

//end  line SESSION
        header('location:debitTable.php');
    }else{
        echo "<script> alert('Incorrect Password') </script>";
    }
}
?>