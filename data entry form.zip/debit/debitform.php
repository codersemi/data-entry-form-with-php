
<?php
session_start();
// echo "Welcome ".$_SESSION['user'];
?>



<?php
include ("debitlogindb.php");

// SESSION
$profile = $_SESSION['user'];

if($profile == true){
    
}else{
    header('location:debitlogin.php');
}
?>







<?php
include ("debitdb.php");
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="debitform.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>my debit</title>
</head>
<body>

<div class="main">
  <h2>Debit Data Entry Form</h2>
  <p>Please fill this form debit data into database </p>
 <center>

 <a href="debittable.php"><button class="mytop">Data</button></a> 
 <a href="debitlogout.php"><button class="logout">Logout</button></a> 

  <form class="form" method="post" autocomplete="off">
  <br>
    <input type="text" value="<?php $result['name'];?>" name="name" id="name" class="input" placeholder="Name" required>
    <br><br>
    <input type="text" value="<?php $result['address'];?>" name="address" id="address" class="input" placeholder="Address" required>
    <br><br>
    <input type="text" value="<?php $result['amount'];?>" name="amount" id="amount" class="input" placeholder="Amount" required>
    <br><br>
    <input type="text" value="<?php $result['date'];?>" name="date" id="date" class="input" placeholder="Date" required>
    <br><br>


    <!-- <input type="text" value="<?php $result['type'];?>" name="type" id="type" class="input" placeholder="Type" required>
    <br><br> -->

    <select value="<?php $result['type'];?>" name="type" id="type" class="input">
      <option value="Debit">Debit</option>
      <option value="Credit">Cretid</option>
    </select>
    <br><br> 


    <input type="text" value="<?php $result['remarks'];?>" name="remarks" id="remarks" class="input" placeholder="Remarks" required>
    <br><br>
    <input type="submit" name="save"  class="enter" value="Save">
    <br><br>
    <a href="#"><input type="reset" class="cencel" value="Cancel"></a>
    <br><br>
  </form>
</center>
  </div>





<!-- this line below PHP CODE -->
<?php

if($_POST['save'])
{
    $name      = $_POST['name'];
    $address   = $_POST['address'];
    $amount    = $_POST['amount'];
    $date      = $_POST['date'];
    $type      = $_POST['type'];
    $remarks   = $_POST['remarks'];

    $query = "INSERT INTO debitdata(name,address,amount,date,type,remarks)VALUES('$name','$address','$amount','$date','$type','$remarks')";
    $data  = mysqli_query($conn,$query);
    if($data){
        echo "<script> alert('Data Successfully Inserted')</script>";
    }else{
        echo "<script> alert('Somthing Wrong! Please Check Your Code.')</script>";
    }
}


?>





</body>
</html>