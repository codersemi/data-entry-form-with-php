<?php
error_reporting(0);

$servername   = "localhost";
$user         = "root";
$pass         = "";
$dbname       = "debit";

$conn = mysqli_connect($servername,$user,$pass,$dbname);
if($conn){
    // echo "Activate";
}else{
    echo "Not Activate";
}
?>