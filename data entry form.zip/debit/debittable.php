
<?php
session_start();
// echo "Welcome ".$_SESSION['user'];
?>



<?php
include ("debitlogindb.php");

// SESSION
$profile = $_SESSION['user'];

if($profile == true){
    
}else{
    header('location:debitlogin.php');
}
?>







<?php
include ("debitdb.php");

$query   = "SELECT * FROM debitdata";
$data    = mysqli_query($conn,$query);
$total   = mysqli_num_rows($data);

if($total !=0){
    // echo "Correct";
    ?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="debittable.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>

<div class="mykhata">
    <h2>Debit Data </h2>
 
    <a href="debitform.php"><button class="mytop">Add New</button></a> 
    <a href="debitlogout.php"><button class="logout">Logout</button></a> 
    

</div>

<table>
    <tr>
        <th id='thdr'>ID</th>
        <th id='thdr'>Full Name</th>
        <th id='thdr'>Address</th>
        <th id='thdr'>Amount</th>
        <th id='thdr'>Date</th>
        <th id='thdr'>Type</th>
        <th id='thdr'>Remarks</th>
        <th id='act' colspan="2">Action</th>
    </tr>
</html>

<?php
while($result = mysqli_fetch_assoc($data))
{
echo "<tr>
          <td>".$result['id']."</td>
          <td>".$result['name']."</td>
          <td>".$result['address']."</td>
          <td>".$result['amount']."</td>
          <td>".$result['date']."</td>
          <td>".$result['type']."</td>
          <td>".$result['remarks']."</td>
        
          <td id='action'><a href='debitupdate.php?id=$result[id]'>Update</a></td>
          <td id='action'><a href='debitdelet.php?id=$result[id]'  onclick='return del();'>Delete</a></td>
          
      </tr>";
}

}else{
    echo "<h1>No More Data</h1>";
}

?>
</table>


<script>
    

    function del(){            
        return confirm("Are you want to sure delete ?");
    }
 </script>
    
