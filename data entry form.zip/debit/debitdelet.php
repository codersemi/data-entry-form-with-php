<?php
include ("debitdb.php");
$id = $_GET['id'];

$query = "DELETE FROM debitdata WHERE id='$id'";
$data  = mysqli_query($conn,$query);

if($data){
    echo "Deleted has been deleted";
    ?>
    <meta http-equiv ="refresh" content="1; url = http://localhost/debit/debittable.php"/>
    <?php
}else{
    echo "Not Now";
}

?>